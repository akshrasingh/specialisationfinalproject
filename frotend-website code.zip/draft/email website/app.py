import time  # Import time module for adding delay
from flask import Flask, render_template, request, redirect, url_for
from transformers import pipeline
from transformers import GPT2LMHeadModel, GPT2Tokenizer
import language_tool_python
from googletrans import Translator
import PyPDF2

app = Flask(__name__)

# Initialize the grammar checker
tool = language_tool_python.LanguageTool('en-US')

# Initialize the Google Translator
translator = Translator()

# Initialize GPT-2 model and tokenizer for reply generation
gpt2_tokenizer = GPT2Tokenizer.from_pretrained('gpt2')
gpt2_model = GPT2LMHeadModel.from_pretrained('gpt2')

# Load the pretrained DistilBERT model for text classification
classifier = pipeline('text-classification', model='distilbert-base-uncased')

# Define the categories you want for your classification
categories = {
    'LABEL_0': 'Personal',
    'LABEL_1': 'Professional',
    'LABEL_2': 'Help',
    'LABEL_3': 'Illegal',
    'LABEL_4': 'Promotion',
    'LABEL_5': 'Other'
}

# Load sentiment analysis pipeline
sentiment_pipeline = pipeline(
    'sentiment-analysis', model="nlptown/bert-base-multilingual-uncased-sentiment")


@app.route('/')
def home():
    return render_template('home.html')


@app.route('/application', methods=["GET", "POST"])
def application():
    if request.method == "POST":
        email_content = request.form.get('email_content', "")
        target_language_email = request.form.get('target_language_email', 'en')
        target_language_file = request.form.get('target_language_file', 'en')
        uploaded_file = request.files.get("file_upload")

        # If a file is uploaded, extract text based on file type
        if uploaded_file:
            if uploaded_file.filename.endswith('.pdf'):
                email_content = extract_pdf_text(uploaded_file)
            elif uploaded_file.filename.endswith('.txt'):
                email_content = extract_txt_text(uploaded_file)

        if email_content:
            # Call processing functions like classification, reply generation, etc.
            classification = classify_email(email_content)
            automated_reply = generate_reply_with_gpt2(email_content)
            sentiment = analyze_sentiment(email_content)
            grammar_check, corrected_content = check_grammar(email_content)

            # Determine which language to translate to
            if uploaded_file:
                translation = translate_content(
                    email_content, target_language_file)
            else:
                translation = translate_content(
                    email_content, target_language_email)
            print(translation)

            # Introduce a 5-second delay before rendering the results
            time.sleep(5)  # Delay for 5 seconds (5000 milliseconds)

            # After processing, pass the result data to the results page
            return render_template('results.html',
                                   classification=classification,
                                   automated_reply=automated_reply,
                                   sentiment=sentiment,
                                   grammar_check=grammar_check,
                                   translation=translation)

        # Show loading GIF while processing
        return render_template('index.html', loading=True)

    return render_template('index.html', loading=False)


def extract_pdf_text(pdf_file):
    pdf_reader = PyPDF2.PdfReader(pdf_file)
    pdf_text = ""
    for page in pdf_reader.pages:
        pdf_text += page.extract_text() + "\n"
    return pdf_text


def extract_txt_text(txt_file):
    txt_content = txt_file.read().decode('utf-8')
    return txt_content


def classify_email(content):
    result = classifier(content)
    label = result[0]['label']
    category = categories.get(label, 'Other')
    return category


def generate_reply_with_gpt2(content):
    prompt = f"Generate a professional email response for the following content:\n\n{content}\n\nResponse:"
    input_ids = gpt2_tokenizer.encode(prompt, return_tensors='pt')
    gpt2_output = gpt2_model.generate(
        input_ids,
        max_length=150,
        num_return_sequences=1,
        no_repeat_ngram_size=2,
        temperature=0.7,
        top_p=0.9
    )
    reply = gpt2_tokenizer.decode(gpt2_output[0], skip_special_tokens=True)
    response = reply.split("Response:")[-1].strip()
    return response


def analyze_sentiment(content):
    sentiment_results = sentiment_pipeline(content)
    labels = [result['label'] for result in sentiment_results]
    scores = [result['score'] for result in sentiment_results]
    sentiment_breakdown = [(label, score)
                           for label, score in zip(labels, scores)]
    return sentiment_breakdown


def check_grammar(content):
    matches = tool.check(content)
    if matches:
        corrected_content = tool.correct(content)
        return f"{len(matches)} issues found. Suggested corrections: {corrected_content}", corrected_content
    else:
        return "No grammar issues found.", content


def translate_content(content, target_language):
    translated = translator.translate(content, dest=target_language)
    return translated.text


if __name__ == "__main__":
    app.run(debug=True)
