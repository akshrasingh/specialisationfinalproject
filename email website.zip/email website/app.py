from flask import Flask, request, render_template
from transformers import pipeline
import language_tool_python

app = Flask(__name__)

# Load sentiment analysis pipeline (using a model from Hugging Face)
sentiment_pipeline = pipeline(
    'sentiment-analysis', model="nlptown/bert-base-multilingual-uncased-sentiment")

# Initialize the grammar checker
tool = language_tool_python.LanguageTool('en-US')


@app.route("/", methods=["GET", "POST"])
def index():
    classification = ""
    automated_reply = ""
    sentiment = ""
    grammar_check = ""
    if request.method == "POST":
        email_content = request.form['email_content']

        # Perform email classification, automated reply generation, sentiment analysis, and grammar check
        classification = classify_email(email_content)
        automated_reply = generate_reply(email_content, classification)
        sentiment = analyze_sentiment(email_content)
        grammar_check = check_grammar(email_content)

        return render_template('index.html',
                               classification=classification,
                               automated_reply=automated_reply,
                               sentiment=sentiment,
                               grammar_check=grammar_check)

    return render_template("index.html")


def classify_email(content):
    if "job opening" in content.lower() or "interview" in content.lower():
        return "Job-Related"
    elif "personal" in content.lower():
        return "Personal"
    elif "document" in content.lower() or "edit" in content.lower():
        return "Document Checking and Editing"
    else:
        return "Professional"


def generate_reply(content, classification):
    if classification == "Job-Related":
        return "Thank you for sharing this opportunity. I am very interested in learning more about the job opening at Microsoft."
    elif classification == "Personal":
        return "Thank you for reaching out! I'll get back to you shortly."
    elif classification == "Document Checking and Editing":
        return "I've received your document. I'll review it and get back to you with feedback soon."
    else:
        return "Thank you for the information. I look forward to further communication."


def analyze_sentiment(content):
    sentiment_result = sentiment_pipeline(content)[0]
    label = sentiment_result['label']
    confidence = sentiment_result['score']

    # Format the output as "Sentiment: LABEL (Confidence: SCORE)"
    return f"Sentiment: {label} (Confidence: {confidence:.2f})"


def check_grammar(content):
    matches = tool.check(content)
    if not matches:
        return "No grammatical errors found.", content
    else:
        grammar_issues = f"Grammar issues found: {len(matches)}"
        corrected_content = language_tool_python.utils.correct(
            content, matches)
        return grammar_issues, corrected_content


if __name__ == "__main__":
    app.run(debug=True)
