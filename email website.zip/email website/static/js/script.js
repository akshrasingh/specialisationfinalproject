// Example JS - You can add interactivity here
document.addEventListener("DOMContentLoaded", function () {
  // Example: Add a smooth scroll to the top on submit
  document.querySelector("form").addEventListener("submit", function () {
    window.scrollTo({ top: 0, behavior: "smooth" });
  });
});
